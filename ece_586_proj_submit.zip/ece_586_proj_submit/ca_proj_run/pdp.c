
/****************************************************************************************/
/*
   ECE - 586 CA 
   Final project : Simulation of PDP-11	
Date : 12th June 2017

Team mates:
Amit Solapurkar
Kalyani Chawak
Kushal Shah
Yuvanesh

 */
/****************************************************************************************/



#include "pdp.h"



int read_memory(int addr);
int write_memory(int addr, int value);

int load_memory(FILE *fp);

FILE *trace;
FILE *br_trace;


int main(int argc, char *argv[])
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int temp_instr = 1;
	int temp_pc_oct = 0;
	int temp_pc_deci = 0;
	int temp_scan;
#ifdef STEP
	int bp_addr = 0;
	int bp_hit = 0;

	int address;
	int address_deci;
	int space;
	int c1;
#endif



	if(argc < 2)
	{
		printf("************************************************* \n");
		printf("Please enter the ascii file name\n\n");
		printf("************************************************* \n");
		return 0;
	}

	/* test file parsing part */
	FILE *fp;
	fp = fopen(argv[1],"r");
	if(fp == NULL)
	{
		printf("************************************************* \n");
		printf("ascii file doesn't exist\n\n");
		printf("Please check the file name again\n\n");
		printf("************************************************* \n");
		return 0;

	}

	load_memory(fp);


	if(PC_val_given == 0)
	{
		printf("************************************************* \n");
		printf("  Please enter the starting PC value :  \n");
		temp_scan = scanf("%d",&temp_pc_oct);

		if (temp_scan != 1)
		{
			printf("Error while reading input!\n");
			exit(1);
		}


		printf("************************************************* \n");
		temp_pc_deci = oct_to_deci(temp_pc_oct);
		PC_val = temp_pc_deci;
		Reg_R7_PC = PC_val;	
	}


#ifdef STEP
	if(argc == 3)
	{
		bp_addr = oct_to_deci(atoi(argv[2]));				
		printf("Break point set after instruction %o (d%d)\n",bp_addr, bp_addr);
	}

#endif


	print_memory();
	print_registers();
	print_status_flags();

	time_t rawtime;
	struct tm * timeinfo;
	char buffer [80];
	char br_buff[80];

	time ( &rawtime );
	timeinfo = localtime ( &rawtime );

	strftime (buffer,80,"TRACE_FILE_%b%d_%H.%M.txt",timeinfo);
	puts (buffer);

	trace = fopen(buffer, "w");

	if (trace == NULL)
	{
		printf("Error while opening file!\n");
		exit(1);
	}

	strftime (br_buff,80,"BRANCH_TRACE_FILE_%b%d_%H.%M.txt",timeinfo);
	puts(br_buff);

	br_trace = fopen(br_buff, "w");

	if (br_trace == NULL)
	{
		printf("Error while opening file!\n");
		exit(1);
	} 

	fprintf(br_trace,"PC value at Branch\tType of Branch\tTargetAddress\tTaken/NotTaken\n\n");

	while(halt == 0)
	{
		temp_instr = instr_fetch();
		number_of_instr++;

		instr_decode(temp_instr);


#ifdef STEP
		while((bp_addr == temp_instr) | (bp_hit))
		{


			bp_hit = 1;

			printf("\nInstruction decoded and executed : %o (d%d)\n",temp_instr, temp_instr);
			printf("\nEnter one of the below option\n");
			printf("\n 1 - Exit the program\n");
			printf("\n 2 - To get memory value for <addr>\n");
			printf("\n 3 - To get memory value for <addr> <range>\n");
			printf("\n 4 - Print first 32 words of memory\n");
			printf("\n 5 - Print Register values\n");
			printf("\n 6 - Print PSW flags(Z, N, C, V)\n");
			printf("\n 7 - Print first 32 words of memory, Registers, PSW flags\n");
			printf("\n 0 - Continue execution to next instruction\n");

			temp_scan = scanf("%d", &c1);
			if (temp_scan != 1)
			{
				printf("Error while reading input!\n");
				exit(1);
			}

			while(c1 != 0)
			{


				if (c1 == 1) {
					printf("\nBreak.... exiting\n");
					exit(1);
				}
				else if (c1 == 2) 
				{
					printf("\nEnter the address you wish to check the value\n");
					temp_scan = scanf("%d", &address);

					if (temp_scan != 1)
					{
						printf("Error while reading input!\n");
						exit(1);
					}


					address_deci = oct_to_deci(address);
					print_memory_addr(address_deci);
				}
				else if (c1 == 3) 
				{
					printf("\nEnter the address\n");
					temp_scan = scanf("%d", &address);

					if (temp_scan != 1)
					{
						printf("Error while reading input!\n");
						exit(1);
					}


					address_deci = oct_to_deci(address);
					printf("\nEnter the range\n");
					temp_scan = scanf("%d", &space);

					if (temp_scan != 1)
					{
						printf("Error while reading input!\n");
						exit(1);
					}



					print_memory_range(address_deci, space);
				}
				else if (c1 == 4) 
				{
					print_memory();
				}
				else if (c1 == 5) 
				{
					print_registers();
				}
				else if (c1 == 6) 
				{
					print_status_flags();
				}
				else if (c1 == 7) 
				{
					print_memory();
					print_registers();
					print_status_flags();
				}



				printf("\nEnter (0-7) option\n");

				temp_scan = scanf("%d", &c1);
				if (temp_scan != 1)
				{
					printf("Error while reading input!\n");
					exit(1);
				}



			}

			if((temp_instr == 0) | (c1 == 0) )
			{
				break;
			}


		}
#endif

	}


#ifdef	DEBUG
	print_memory();
	print_registers();
	print_status_flags();
#endif

	printf("Total number of instructions = %d \n",number_of_instr);

	fclose(fp);

	fclose(trace);
	fclose(br_trace);

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif


	return 0;

}




int load_memory(FILE *fp)
{

	char test_input_ascii[256];
	int temp_load_ptr;
	int temp_data;


	init_pdp_memory();

	while(fscanf(fp,"%s",test_input_ascii)!=EOF)
	{

#ifdef	DEBUG3
		printf("\n Address : %s\n",test_input_ascii);
		printf("\n first char : %c\n",test_input_ascii[0]);


#endif

		if (test_input_ascii[0] == '*')
		{
			PC_val = extract_val(test_input_ascii);
			Reg_R7_PC = PC_val;	
			PC_val_given = 1;
#ifdef	DEBUG3
			printf("PC_val is %o (d%d)  \n", PC_val, PC_val);
#endif
		}

		if (test_input_ascii[0] == '-')
		{
			temp_data = extract_val(test_input_ascii);
#ifdef	DEBUG3
			printf("Value to be loaded at the curent load address\n");
			printf("Value getting loaded at the current address = %o (d%d) \n", temp_data, temp_data );
#endif
			temp_load_ptr = load_ptr;
			store_pdp_memory(temp_load_ptr,temp_data);

			increment_load_ptr(2);

		}

		if (test_input_ascii[0] == '@')
		{
			temp_load_ptr = extract_val(test_input_ascii);
#ifdef	DEBUG3
			printf("Change to the load address\n");
			printf("New load address = %o (d%d) \n", temp_load_ptr, temp_load_ptr);
#endif
			update_load_ptr(temp_load_ptr);


		}



	}


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return 0;

}


int extract_val(char *test_input_ascii)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	char temp_test_input_ascii[6];
	int number_oct = 0;
	int number_deci = 0;

	for(int i=1; i<7;i++)
	{
		temp_test_input_ascii[i-1] = test_input_ascii[i];

		if(i == 6)
		{
			number_oct = atoi(temp_test_input_ascii);				
			number_deci = oct_to_deci(number_oct);
#ifdef	DEBUG3
			printf("\nnumber_oct = %d  \n", number_oct);
			printf("\nnumber_deci = %d  \n", number_deci);
#endif
		}

	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return number_deci;



}

int oct_to_deci(int octal)
{


#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int decimal = 0;
	int i = 0;

#ifdef	DEBUG3
	printf(" octal number: %d\n",octal);
#endif
	while (octal != 0)
	{
		decimal =  decimal +(octal % 10)* pow(8, i++);
		octal = octal / 10;
	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return decimal;

}




int deci_to_oct(int deci)
{
	int octal = 0, i = 1;

	while (deci != 0)
	{
		octal += (deci % 8) * i;
		deci /= 8;
		i *= 10;
	}

	return octal;
}






int init_pdp_memory()
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif
	for(int i = 0; i < 64*1024*2; i++)
	{
		pdp_memory[i] = 0;
	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return 0;

}


int store_pdp_memory(int temp_load_ptr, int temp_data)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	pdp_memory[temp_load_ptr] = temp_data;

#ifdef	DEBUG3
	printf("pdp_memory is %o (d%d) \n", pdp_memory[temp_load_ptr], pdp_memory[temp_load_ptr]);
	printf("load ptr is %o (d%d) \n", temp_load_ptr, temp_load_ptr);
#endif


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return 0;

}



int set_pdp_memory(int temp_load_ptr, int temp_data)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	pdp_memory[temp_load_ptr] = temp_data;
	write_to_trace(1,temp_load_ptr); 

#ifdef	DEBUG3
	printf("pdp_memory is %o (d%d) \n", pdp_memory[temp_load_ptr], pdp_memory[temp_load_ptr]);
	printf("load ptr is %o (d%d) \n", temp_load_ptr, temp_load_ptr);
#endif


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return 0;

}


int get_pdp_memory(int temp_load_ptr)
{

	int temp_data;

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	temp_data = pdp_memory[temp_load_ptr];
	write_to_trace(0,temp_load_ptr); 

#ifdef	DEBUG3
	printf("pdp_memory is %o (d%d) \n", temp_data, temp_data);
	printf("load ptr is %o (d%d) \n", temp_load_ptr, temp_load_ptr);
#endif


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return temp_data;

}


int get_mem(int temp_load_ptr)
{

	int temp_data;

	temp_data = pdp_memory[temp_load_ptr];

	return temp_data;

}



int increment_load_ptr(int count)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	load_ptr = load_ptr + count;

#ifdef	DEBUG3
	printf("\n load address incremented by %d  \n", count);
	printf("\n New load address %o (d%d)  \n", load_ptr, load_ptr);
#endif

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}


int update_load_ptr(int temp_load_ptr)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	load_ptr = temp_load_ptr;

#ifdef	DEBUG3
	printf("\nNew load address updated %o (d%d)  \n", load_ptr, load_ptr);
#endif


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;


}


int print_memory_addr(int addr)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif


#ifdef	DEBUG
	printf("************************************************* \n");
	printf("\nPDP-11 memory address value \n");
	printf("************************************************* \n");

	printf("\nLocation : %o (d%d)  ", addr, addr);
	printf("Value : %o (d%d) \n", pdp_memory[addr], pdp_memory[addr]);

	printf("************************************************* \n");
#endif

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;



}



int print_memory_range(int addr, int space)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int temp_load_ptr = addr;

#ifdef	DEBUG
	printf("************************************************* \n");
	printf("\nPDP-11 memory \n");
	printf("************************************************* \n");
#endif

	for(int i=0;i < space; i+=2)
	{
#ifdef	DEBUG
		printf("\nLocation : %o (d%d)  ", temp_load_ptr, temp_load_ptr);
		printf("Value : %o (d%d) \n", pdp_memory[temp_load_ptr], pdp_memory[temp_load_ptr]);
#endif
		temp_load_ptr+=2;
	}

	printf("************************************************* \n");
#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;



}



int print_memory()
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int temp_load_ptr = 0;

#ifdef	DEBUG
	printf("************************************************* \n");
	printf("\nPDP-11 memory (32 words) \n");
	printf("************************************************* \n");
#endif

	for(int i=0;i<64;i+=2)
	{
#ifdef	DEBUG
		printf("\nLocation : %o (d%d)  ", temp_load_ptr, temp_load_ptr);
		printf("Value : %o (d%d) \n", pdp_memory[temp_load_ptr], pdp_memory[temp_load_ptr]);
#endif
		temp_load_ptr+=2;
	}

	printf("************************************************* \n");
#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;



}



int print_registers()
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif


#ifdef	DEBUG
	printf("************************************************* \n");
	printf("\nPDP-11 Registers \n");
	printf("************************************************* \n");

	printf("\nReg_R0 : %o (d%d)  \n", Reg_R0, Reg_R0);
	printf("\nReg_R1 : %o (d%d)  \n", Reg_R1, Reg_R1);
	printf("\nReg_R2 : %o (d%d)  \n", Reg_R2, Reg_R2);
	printf("\nReg_R3 : %o (d%d)  \n", Reg_R3, Reg_R3);
	printf("\nReg_R4 : %o (d%d)  \n", Reg_R4, Reg_R4);
	printf("\nReg_R5 : %o (d%d)  \n", Reg_R5, Reg_R5);
	printf("\nReg_R6_SP : %o (d%d)  \n", Reg_R6_SP, Reg_R6_SP);
	printf("\nReg_R7_PC : %o (d%d)  \n", Reg_R7_PC, Reg_R7_PC);
	printf("************************************************* \n");
#endif

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;



}


int print_status_flags()
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif


#ifdef	DEBUG
	printf("************************************************* \n");
	printf("\nPDP-11 Status flags \n");
	printf("************************************************* \n");

	printf("\nPSW_N : %d  \n", PSW_N);
	printf("\nPSW_Z : %d  \n", PSW_Z);
	printf("\nPSW_V : %d  \n", PSW_V);
	printf("\nPSW_C : %d  \n", PSW_C);
	printf("************************************************* \n");
#endif

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;



}




int instr_fetch()
{


#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int temp_instr;


	temp_instr = pdp_memory[PC_val];
	write_to_trace(2,PC_val); 

	if(temp_instr == 0)
	{
		halt = 1;
	}

#ifdef	DEBUG3
	printf("instr getting fetched is %o (d%d) \n", temp_instr, temp_instr);
	printf("PC_val is %o (d%d) \n", PC_val, PC_val);
#endif

	increment_PC_val(2);

#ifdef	DEBUG3
	printf("New PC_val is %o (d%d) \n", PC_val, PC_val);
#endif

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return temp_instr;

}


int increment_PC_val(int count)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PC_val = (PC_val + 2) & 0177777; 
	Reg_R7_PC = PC_val;	


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;

}

int decrement_PC_val(int count)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PC_val = (PC_val - 2) & 0177777; 
	Reg_R7_PC = PC_val;	


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;

}


int instr_decode(int temp_instr)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int src_val = 0;
	int src2_val = 0;
	int dest_val = 0;
	int br_val = 0;

	int src_reg = 0;
	int src_mod = 0;
	int src2_reg = 0;
	int src2_mod = 0;
	int dest_reg = 0;
	int dest_mod = 0;


	src_mod = (temp_instr>>9) & 0x7;  
	src_reg = (temp_instr>>6) & 0x7;  

	dest_mod = (temp_instr>>3) & 0x7;  
	dest_reg = (temp_instr) & 0x7;  

	src2_mod = (temp_instr>>3) & 0x7;  
	src2_reg = (temp_instr) & 0x7;  

#ifdef	DEBUG3
	printf("instr getting decoded is %o (d%d) \n", temp_instr, temp_instr);
#endif


	/* decode temp_instr<15:12> */

	switch ((temp_instr >> 12) & 017) 
	{  


		/* Opcode 0: no operands, branches, JSR */

		case 000:
			switch ((temp_instr >> 6) & 077) 
			{                      
				case 000:                                        
					if (temp_instr >= 000010) 
					{                         
#ifdef	DEBUG3
						printf("Instruction not supported \n");
#endif
						break;
					}
					switch (temp_instr) 
					{                               
						case 0:                                     /* HALT */
							halt = 1;
							break;
						case 1:                                     
						case 2:                                     
						case 3:                                     
						case 4:                                     
						case 5:                                     
						case 6:                                     
						case 7:                                     
#ifdef	DEBUG3
							printf("Instruction not supported \n");
#endif
							break;
					}                                       
					break;                                      

				case 001:                                       /* JMP */
					//FIXME check again
					if(!dest_mod)
					{
#ifdef	DEBUG
						printf("Cant use register mode for JMP instruction\n");
#endif
						return 0;
					}

					//dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = get_dest_addr(dest_mod, dest_reg);
					dest_val = dest_val & 0177777;
					write_to_br_trace(PC_val-2,temp_instr,dest_val,1);
					JMP_PC (dest_val);
					break;                                      /* end JMP */





				case 002:                                       

					if (temp_instr < 000210) 
					{                          /* RTS */

						dest_val = get_dest_val(0, dest_reg);
						if(dest_reg != 7)
						{
							write_to_br_trace(PC_val-2,temp_instr,dest_val,1);
						}
						JMP_PC (dest_val);
						//FIXME 
						src2_val = get_dest_val(1, 6);
						//src2_val = get_dest_val(0, 6);

						write_dest_val(0, dest_reg, src2_val);

						write_to_br_trace(PC_val-2,temp_instr,src2_val,1);

						if (dest_reg != 6)
							Reg_R6_SP = (Reg_R6_SP + 2) & 0177777;
						break;
					}                                       
					if (temp_instr < 000240) 
					{                        
#ifdef	DEBUG3
						printf("Instruction not supported \n");
#endif
						break;
					}                                       
					if (temp_instr == 000240) 
					{                        
#ifdef	DEBUG3
						printf("NOP Instruction \n");
#endif
						break;
					}                                       
					if (temp_instr < 000260) 
					{                          /* clear PSW */
						if (temp_instr & 010)
						{	clear_PSW_N(); }
						if (temp_instr & 004)
						{	clear_PSW_Z(); }
						if (temp_instr & 002)
						{	clear_PSW_V(); }
						if (temp_instr & 001)
						{	clear_PSW_C(); }
						break;
					}                                       /* end if clear PSW */
					if (temp_instr & 010)                               /* set PSW */
					{	set_PSW_N(); }
					if (temp_instr & 004)
					{	set_PSW_Z(); }
					if (temp_instr & 002)
					{	set_PSW_V(); }
					if (temp_instr & 001)
					{	set_PSW_C(); }
					break;                                      




					break;                                      


				case 003:                                       /* SWAB */
					dest_val = get_dest_val(dest_mod, dest_reg);
					dest_val = ((dest_val & 0377) << 8) | ((dest_val >> 8) & 0377);



					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);


					//PSW update
					if(GET_SIGN_B(dest_val & 0377))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}

					if(GET_PSW_Z(dest_val & 0377))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}


					clear_PSW_V();
					clear_PSW_C();

					break;                                      /* end SWAB */

				case 004: case 005:                             /* BR */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					write_to_br_trace(PC_val-2,temp_instr,br_val,1);          /* BR */
					BRANCH_forw (temp_instr);
					break;

				case 006: case 007:                             /* BR */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					write_to_br_trace(PC_val-2,temp_instr,br_val,1);          /* BR */
					BRANCH_back (temp_instr);
					break;

				case 010: case 011:                             /* BNE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;				/* BNE */
					if (PSW_Z == 0) 
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 012: case 013:                             /* BNE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_Z == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}

					break;

				case 014: case 015:                             /* BEQ */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_Z) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}

					break;

				case 016: case 017:                             /* BEQ */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_Z) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}

					break;

				case 020: case 021:                             /* BGE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if ((PSW_N ^ PSW_V) == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);                                        
					}
					break;

				case 022: case 023:                             /* BGE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if ((PSW_N ^ PSW_V) == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 024: case 025:                             /* BLT */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_N ^ PSW_V) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 026: case 027:                             /* BLT */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_N ^ PSW_V) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 030: case 031:                             /* BGT */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if ((PSW_Z | (PSW_N ^ PSW_V)) == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 032: case 033:                             /* BGT */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if ((PSW_Z | (PSW_N ^ PSW_V)) == 0) 
					{ 

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr); 
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 034: case 035:                             /* BLE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_Z | (PSW_N ^ PSW_V)) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 036: case 037:                             /* BLE */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_Z | (PSW_N ^ PSW_V)) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 040: case 041: case 042: case 043:         /* JSR */
				case 044: case 045: case 046: case 047:
					//FIXME check again


					dest_val = get_dest_addr(dest_mod, dest_reg);
					//dest_val = get_dest_val(dest_mod, dest_reg);
					src_val = get_src_val(0, src_reg);

					Reg_R6_SP = (Reg_R6_SP - 2) & 0177777;
					//FIXME 
					write_dest_val(1, 6, src_val);   // pushing on top of the stack
					//write_dest_val(0, 6, src_val);   // pushing on top of the stack

					write_dest_val(0, src_reg, PC_val);   
					write_to_br_trace(PC_val-2,temp_instr,dest_val,1);

					JMP_PC (dest_val & 0177777);

					break;                                      /* end JSR */

				case 050:                                       /* CLR */

					clear_PSW_N();
					clear_PSW_V();
					clear_PSW_C();
					set_PSW_Z();

					dest_val = get_dest_addr(dest_mod, dest_reg);
					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, 0);

					break;

				case 051:                                       /* COM */


					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = dest_val ^ 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}


					clear_PSW_V();
					set_PSW_C();

					break;

				case 052:                                       /* INC */


					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = ( dest_val + 1 ) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(dest_val == 0100000)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					break;

				case 053:                                       /* DEC */


					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = ( dest_val - 1 ) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(dest_val == 077777)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					break;

				case 054:                                       /* NEG */

					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = (-dest_val) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(dest_val == 0100000)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					if(dest_val == 0)
					{
						clear_PSW_C();
					}
					else
					{
						set_PSW_C();
					}


					break;

				case 055:                                       /* ADC */



					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = (dest_val + PSW_C) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(PSW_C && (dest_val == 0100000))
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					if(PSW_C && (dest_val == 0))
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}

					break;

				case 056:                                       /* SBC */

					dest_val = get_dest_val(dest_mod, dest_reg);

					dest_val = (dest_val - PSW_C) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(PSW_C && (dest_val == 077777))
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					if(PSW_C && (dest_val == 0177777))
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}


					break;

				case 057:                                       /* TST */



					dest_val = get_dest_val(dest_mod, dest_reg);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					clear_PSW_V();
					clear_PSW_C();


					break;

				case 060:                                       /* ROR */


					src_val = get_src_val(dest_mod, dest_reg);

					dest_val = (src_val >> 1) | (PSW_C << 15);

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(PSW_N ^ PSW_C)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					if(src_val & 1)
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}

					break;

				case 061:                                       /* ROL */


					src_val = get_src_val(dest_mod, dest_reg);

					dest_val = ((src_val << 1) | PSW_C) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);


					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();
					}
					else
					{
						clear_PSW_N();
					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();
					}
					else
					{
						clear_PSW_Z();
					}


					if(GET_SIGN_W(src_val))
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}



					if(PSW_N ^ PSW_C)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					break;

				case 062:                                       /* ASR */



					src_val = get_src_val(dest_mod, dest_reg);

					dest_val = (src_val >> 1) | (src_val & 0100000);

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);

					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();

					}
					else
					{
						clear_PSW_N();

					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();

					}
					else
					{
						clear_PSW_Z();

					}

					if(PSW_N ^ PSW_C)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					if(src_val & 1)
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}

					break;

				case 063:                                       /* ASL */


					src_val = get_src_val(dest_mod, dest_reg);

					dest_val = (src_val << 1) & 0177777;

					avoid_repeat(dest_mod, dest_reg);

					write_dest_val(dest_mod, dest_reg, dest_val);


					if(GET_SIGN_W(dest_val))
					{
						set_PSW_N();
					}
					else
					{
						clear_PSW_N();
					}


					if(GET_PSW_Z(dest_val))
					{
						set_PSW_Z();
					}
					else
					{
						clear_PSW_Z();
					}


					if(GET_SIGN_W(src_val))
					{
						set_PSW_C();
					}
					else
					{
						clear_PSW_C();
					}



					if(PSW_N ^ PSW_C)
					{
						set_PSW_V();
					}
					else
					{
						clear_PSW_V();
					}

					break;


				case 067:                                       /* SXT */


					dest_val = get_dest_addr(dest_mod, dest_reg);
					avoid_repeat(dest_mod, dest_reg);

					dest_val = PSW_N? 0177777: 0;

					write_dest_val(dest_mod, dest_reg, dest_val);


					if(PSW_N ^ 1)
					{
						set_PSW_Z();
					}
					else
					{
						clear_PSW_Z();
					}


					clear_PSW_V();

					break;


				default:
#ifdef	DEBUG3
					printf("Instruction not supported \n");
#endif
					break;
			}                                          
			break;                                          /* end case 000 */

			/* Opcodes 01 - 06: double operand word instructions

			 */

		case 001:                                           /* MOV */


			src_val = get_src_val(src_mod, src_reg);

			dest_val = get_dest_addr(dest_mod, dest_reg);
			avoid_repeat(dest_mod, dest_reg);



			write_dest_val(dest_mod, dest_reg, src_val);


			//PSW update
			if(GET_SIGN_W(src_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(src_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}


			clear_PSW_V();
			//PSW update
			break;                                          


		case 002:                                           /* CMP */

			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = (src_val - src2_val) & 0177777;

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}


			if(GET_SIGN_W ((src_val ^ src2_val) & (~src2_val ^ dest_val)))
			{
				set_PSW_V();
			}
			else
			{
				clear_PSW_V();

			}

			if(src_val < src2_val)
			{
				set_PSW_C();

			}
			else
			{
				clear_PSW_C();

			}

			//PSW update

			break;

		case 003:                                           /* BIT */

			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = src2_val & src_val;

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}


			clear_PSW_V();


			//PSW update

			break;

		case 004:                                           /* BIC */
			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = src2_val & ~src_val;

			avoid_repeat(dest_mod, dest_reg);

			write_dest_val(dest_mod, dest_reg, dest_val);

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}


			clear_PSW_V();


			//PSW update

			break;

		case 005:                                           /* BIS */

			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = src2_val | src_val;

			avoid_repeat(dest_mod, dest_reg);

			write_dest_val(dest_mod, dest_reg, dest_val);

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}


			clear_PSW_V();

			//PSW update

			break;


		case 006:                                           /* ADD */

			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = (src2_val + src_val) & 0177777;

			avoid_repeat(dest_mod, dest_reg);

			write_dest_val(dest_mod, dest_reg, dest_val);

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}

			if(GET_SIGN_W ((~src_val ^ src2_val) & (src2_val ^ dest_val)))
			{
				set_PSW_V();
			}
			else
			{
				clear_PSW_V();

			}

			if(dest_val < src_val)
			{
				set_PSW_C();

			}
			else
			{
				clear_PSW_C();

			}

			//PSW update

			break;




		case 007:				/* SOB */

			if(((temp_instr >> 9) & 07) == 7)	
			{

				src_val = get_src_val(0, src_reg);

				src_val = (src_val - 1) & 0177777;

				write_dest_val(0, src_reg, src_val);



				if(src_val)
				{
					br_val = (PC_val - (2 * (temp_instr & 077))) & 0177777;
					write_to_br_trace(PC_val-2,temp_instr,br_val,1);

					JMP_PC((PC_val - (2 * (temp_instr & 077))) & 0177777);

				}
			}

			break;                            



			/* Opcode 10: branches, traps, SOPs */

		case 010:
			switch ((temp_instr >> 6) & 077) 
			{                      /* decode temp_instr<11:6> */

				case 000: case 001:                             /* BPL */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_N == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 002: case 003:                             /* BPL */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_N == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 004: case 005:                             /* BMI */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_N) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 006: case 007:                             /* BMI */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_N)
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 010: case 011:                             /* BHI */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if ((PSW_C | PSW_Z) == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 012: case 013:                             /* BHI */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if ((PSW_C | PSW_Z) == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 014: case 015:                             /* BLOS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_C | PSW_Z) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 016: case 017:                             /* BLOS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_C | PSW_Z) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 020: case 021:                             /* BVC */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_V == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 022: case 023:                             /* BVC */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_V == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 024: case 025:                             /* BVS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_V) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 026: case 027:                             /* BVS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_V) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 030: case 031:                             /* BCC / BHIS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_C == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 032: case 033:                             /* BCC / BHIS */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_C == 0) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;

				case 034: case 035:                             /* BCS / BLO */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) & 0377)) & 0177777;
					if (PSW_C) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_forw (temp_instr);
					} 
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					} 
					break;

				case 036: case 037:                             /* BCS / BLO */
					br_val = (PC_val + (((temp_instr) + (temp_instr)) | 0177400)) & 0177777;
					if (PSW_C) 
					{

						write_to_br_trace(PC_val-2,temp_instr,br_val,1);
						BRANCH_back (temp_instr);
					}
					else
					{
						write_to_br_trace(PC_val-2,temp_instr,br_val,0);
					}
					break;


				case 050:                                       /* CLRB */
					break;

				case 051:                                       /* COMB */
					break;

				case 052:                                       /* INCB */
					break;

				case 053:                                       /* DECB */
					break;

				case 054:                                       /* NEGB */
					break;

				case 055:                                       /* ADCB */
					break;

				case 056:                                       /* SBCB */
					break;

				case 057:                                       /* TSTB */
					break;

				case 060:                                       /* RORB */
					break;

				case 061:                                       /* ROLB */
					break;

				case 062:                                       /* ASRB */
					break;

				case 063:                                       /* ASLB */
					break;


				default:
#ifdef	DEBUG3
					printf("Instruction not supported \n");
#endif
					break;
			}                                           
			break;                                          /* end case 010 */

			/* Opcodes 11 - 16: double operand byte instructions

			 */

		case 011:                                           /* MOVB */
			break;

		case 012:                                           /* CMPB */
			break;

		case 013:                                           /* BITB */
			break;

		case 014:                                           /* BICB */
			break;

		case 015:                                           /* BISB */
			break;

		case 016:                                           /* SUB */

			src_val = get_src_val(src_mod, src_reg);
			src2_val = get_src_val(src2_mod, src2_reg);


			dest_val = (src2_val - src_val) & 0177777;

			avoid_repeat(dest_mod, dest_reg);

			write_dest_val(dest_mod, dest_reg, dest_val);

			//PSW update
			if(GET_SIGN_W(dest_val))
			{
				set_PSW_N();

			}
			else
			{
				clear_PSW_N();

			}

			if(GET_PSW_Z(dest_val))
			{
				set_PSW_Z();

			}
			else
			{
				clear_PSW_Z();

			}

			if(GET_SIGN_W ((src_val ^ src2_val) & (~src2_val ^ dest_val)))
			{
				set_PSW_V();
			}
			else
			{
				clear_PSW_V();

			}

			if(src2_val < src_val)
			{
				set_PSW_C();

			}
			else
			{
				clear_PSW_C();

			}

			//PSW update

			break;

	}







#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return 0;

}




int get_src_val(int src_mod, int src_reg)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif
	int return_src_val = 0;
	int temp_x = 0;
	int temp_addr = 0;
	int eff_addr = 0;
	int temp_addr_of_addr = 0;

	switch(src_mod)
	{
		case 0:
#ifdef	DEBUG3
			printf("\n(SRC ) Rn Register mode\n");
#endif
			switch(src_reg)
			{
				case 0:
					return_src_val = Reg_R0;	
					break;

				case 1:
					return_src_val = Reg_R1;	
					break;

				case 2:
					return_src_val = Reg_R2;	
					break;

				case 3:
					return_src_val = Reg_R3;	
					break;

				case 4:
					return_src_val = Reg_R4;	
					break;

				case 5:
					return_src_val = Reg_R5;	
					break;

				case 6:
					return_src_val = Reg_R6_SP;	
					break;

				case 7:
					return_src_val = Reg_R7_PC;	
					break;

				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}
			break;

		case 1:
#ifdef	DEBUG3
			printf("\n(SRC) (Rn) Register deferred mode\n");
#endif
			switch(src_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 1:
					temp_addr = Reg_R1;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 2:
					temp_addr = Reg_R2;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 3:
					temp_addr = Reg_R3;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 4:
					temp_addr = Reg_R4;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 5:
					temp_addr = Reg_R5;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_src_val = get_pdp_memory(temp_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 2:
#ifdef	DEBUG3
			printf("\n(SRC) (Rn)+ Autoincrement mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_src_val = get_pdp_memory(temp_addr);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 3:
#ifdef	DEBUG3
			printf("\n(SRC) @(Rn)+ Autoincrement deferred mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 4:
#ifdef	DEBUG3
			printf("\n(SRC) -(Rn) Autodecrement mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					return_src_val = get_pdp_memory(temp_addr);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					return_src_val = get_pdp_memory(temp_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 5:
#ifdef	DEBUG3
			printf("\n(SRC) @-(Rn) Autodecrement deferred mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 6:
#ifdef	DEBUG3
			printf("\n(SRC) X(Rn) Index mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_src_val = get_pdp_memory(eff_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		case 7:
#ifdef	DEBUG3
			printf("\n(SRC) @X(Rn) Index deferred mode\n");
#endif

			switch(src_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_src_val = get_pdp_memory(temp_addr_of_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" SRC reg %d doesn't exist\n",src_reg);	
#endif
					break;


			}	
			break;

		default:
#ifdef	DEBUG3
			printf("Addressing mode %d doesn't exist\n",src_mod);	
#endif
			break;



	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif

	return return_src_val;

}



int get_dest_val(int dest_mod, int dest_reg)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif


	int return_dest_val = 0;
	int temp_x = 0;
	int temp_addr = 0;
	int eff_addr = 0;
	int temp_addr_of_addr = 0;



	switch(dest_mod)
	{
		case 0:
#ifdef	DEBUG3
			printf("\n(DEST ) Rn Register mode\n");
#endif
			switch(dest_reg)
			{
				case 0:
					return_dest_val = Reg_R0;	
					break;

				case 1:
					return_dest_val = Reg_R1;	
					break;

				case 2:
					return_dest_val = Reg_R2;	
					break;

				case 3:
					return_dest_val = Reg_R3;	
					break;

				case 4:
					return_dest_val = Reg_R4;	
					break;

				case 5:
					return_dest_val = Reg_R5;	
					break;

				case 6:
					return_dest_val = Reg_R6_SP;	
					break;

				case 7:
					return_dest_val = Reg_R7_PC;	
					break;

				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}
			break;

		case 1:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn) Register deferred mode\n");
#endif
			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 1:
					temp_addr = Reg_R1;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 2:
					temp_addr = Reg_R2;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 3:
					temp_addr = Reg_R3;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 4:
					temp_addr = Reg_R4;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 5:
					temp_addr = Reg_R5;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_dest_val = get_pdp_memory(temp_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 2:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn)+ Autoincrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_dest_val = get_pdp_memory(temp_addr);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 3:
#ifdef	DEBUG3
			printf("\n(DEST) @(Rn)+ Autoincrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 4:
#ifdef	DEBUG3
			printf("\n(DEST) -(Rn) Autodecrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					return_dest_val = get_pdp_memory(temp_addr);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					return_dest_val = get_pdp_memory(temp_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 5:
#ifdef	DEBUG3
			printf("\n(DEST) @-(Rn) Autodecrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 6:
#ifdef	DEBUG3
			printf("\n(DEST) X(Rn) Index mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = get_pdp_memory(eff_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 7:
#ifdef	DEBUG3
			printf("\n(DEST) @X(Rn) Index deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = get_pdp_memory(temp_addr_of_addr);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	

			break;

		default:
#ifdef	DEBUG3
			printf("Addressing mode %d doesn't exist\n",dest_mod);	
#endif
			break;



	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return return_dest_val;

}

////////////////////////////////////////////////////////////////

int get_dest_addr(int dest_mod, int dest_reg)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif


	int return_dest_val = 0;
	int temp_x = 0;
	int temp_addr = 0;
	int eff_addr = 0;
	int temp_addr_of_addr = 0;



	switch(dest_mod)
	{
		case 0:
#ifdef	DEBUG3
			printf("\n(DEST ) Rn Register mode\n");
#endif
			switch(dest_reg)
			{
				case 0:
					return_dest_val = Reg_R0;	
					break;

				case 1:
					return_dest_val = Reg_R1;	
					break;

				case 2:
					return_dest_val = Reg_R2;	
					break;

				case 3:
					return_dest_val = Reg_R3;	
					break;

				case 4:
					return_dest_val = Reg_R4;	
					break;

				case 5:
					return_dest_val = Reg_R5;	
					break;

				case 6:
					return_dest_val = Reg_R6_SP;	
					break;

				case 7:
					return_dest_val = Reg_R7_PC;	
					break;

				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}
			break;

		case 1:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn) Register deferred mode\n");
#endif
			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_dest_val = temp_addr;
					break;

				case 1:
					temp_addr = Reg_R1;
					return_dest_val = temp_addr;
					break;

				case 2:
					temp_addr = Reg_R2;
					return_dest_val = temp_addr;
					break;

				case 3:
					temp_addr = Reg_R3;
					return_dest_val = temp_addr;
					break;

				case 4:
					temp_addr = Reg_R4;
					return_dest_val = temp_addr;
					break;

				case 5:
					temp_addr = Reg_R5;
					return_dest_val = temp_addr;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_dest_val = temp_addr;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_dest_val = temp_addr;
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 2:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn)+ Autoincrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					return_dest_val = temp_addr;
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					return_dest_val = temp_addr;
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					return_dest_val = temp_addr;
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					return_dest_val = temp_addr;
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					return_dest_val = temp_addr;
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					return_dest_val = temp_addr;
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					return_dest_val = temp_addr;
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					return_dest_val = temp_addr;
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 3:
#ifdef	DEBUG3
			printf("\n(DEST) @(Rn)+ Autoincrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 4:
#ifdef	DEBUG3
			printf("\n(DEST) -(Rn) Autodecrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					return_dest_val = temp_addr;
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					return_dest_val = temp_addr;
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					return_dest_val = temp_addr;
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					return_dest_val = temp_addr;
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					return_dest_val = temp_addr;
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					return_dest_val = temp_addr;
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					return_dest_val = temp_addr;
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					return_dest_val = temp_addr;
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 5:
#ifdef	DEBUG3
			printf("\n(DEST) @-(Rn) Autodecrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_pdp_memory(temp_addr);
					return_dest_val = temp_addr_of_addr;
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 6:
#ifdef	DEBUG3
			printf("\n(DEST) X(Rn) Index mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					return_dest_val = eff_addr;
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 7:
#ifdef	DEBUG3
			printf("\n(DEST) @X(Rn) Index deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 1:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 2:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 3:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 4:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 5:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 6:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;

				case 7:
					temp_x = get_pdp_memory(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_pdp_memory(eff_addr);
					return_dest_val = temp_addr_of_addr;
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	

			break;

		default:
#ifdef	DEBUG3
			printf("Addressing mode %d doesn't exist\n",dest_mod);	
#endif
			break;



	}

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return return_dest_val;

}
////////////////////////////////////////////////////////////////

int write_dest_val(int dest_mod, int dest_reg, int src_val)
{

#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	int temp_x = 0;
	int temp_addr = 0;
	int eff_addr = 0;
	int temp_addr_of_addr = 0;


	switch(dest_mod)
	{

		case 0:
#ifdef	DEBUG3
			printf("\n(DEST) Rn Register mode\n");
#endif
			switch(dest_reg)
			{
				case 0:

					Reg_R0 = src_val;
					break;

				case 1:

					Reg_R1 = src_val;
					break;

				case 2:

					Reg_R2 = src_val;
					break;

				case 3:

					Reg_R3 = src_val;
					break;

				case 4:

					Reg_R4 = src_val;
					break;

				case 5:

					Reg_R5 = src_val;
					break;

				case 6:

					Reg_R6_SP = src_val;
					break;

				case 7:

					Reg_R7_PC = src_val;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}
			break;

		case 1:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn) Register deferred mode\n");
#endif
			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 1:
					temp_addr = Reg_R1;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 2:
					temp_addr = Reg_R2;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 3:
					temp_addr = Reg_R3;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 4:
					temp_addr = Reg_R4;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 5:
					temp_addr = Reg_R5;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					set_pdp_memory(temp_addr, src_val);
					break;

				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 2:
#ifdef	DEBUG3
			printf("\n(DEST) (Rn)+ Autoincrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					set_pdp_memory(temp_addr, src_val);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					set_pdp_memory(temp_addr, src_val);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					set_pdp_memory(temp_addr, src_val);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					set_pdp_memory(temp_addr, src_val);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					set_pdp_memory(temp_addr, src_val);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					set_pdp_memory(temp_addr, src_val);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					set_pdp_memory(temp_addr, src_val);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					set_pdp_memory(temp_addr, src_val);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 3:
#ifdef	DEBUG3
			printf("\n(DEST) @(Rn)+ Autoincrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R0 += 2;
					break;

				case 1:
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R1 += 2;
					break;

				case 2:
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R2 += 2;
					break;

				case 3:
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R3 += 2;
					break;

				case 4:
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R4 += 2;
					break;

				case 5:
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R5 += 2;
					break;

				case 6:
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R6_SP += 2;
					break;

				case 7:
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					Reg_R7_PC += 2;
					PC_val = Reg_R7_PC;	
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 4:
#ifdef	DEBUG3
			printf("\n(DEST) -(Rn) Autodecrement mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					set_pdp_memory(temp_addr, src_val);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					set_pdp_memory(temp_addr, src_val);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 5:
#ifdef	DEBUG3
			printf("\n(DEST) @-(Rn) Autodecrement deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					Reg_R0 -= 2;
					temp_addr = Reg_R0;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 1:
					Reg_R1 -= 2;
					temp_addr = Reg_R1;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 2:
					Reg_R2 -= 2;
					temp_addr = Reg_R2;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 3:
					Reg_R3 -= 2;
					temp_addr = Reg_R3;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 4:
					Reg_R4 -= 2;
					temp_addr = Reg_R4;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 5:
					Reg_R5 -= 2;
					temp_addr = Reg_R5;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 6:
					Reg_R6_SP -= 2;
					temp_addr = Reg_R6_SP;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 7:
					Reg_R7_PC -= 2;
					PC_val = Reg_R7_PC;	
					temp_addr = Reg_R7_PC;
					temp_addr_of_addr = get_mem(temp_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 6:
#ifdef	DEBUG3
			printf("\n(DEST) X(Rn) Index mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 1:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 2:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 3:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 4:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 5:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 6:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;

				case 7:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					set_pdp_memory(eff_addr, src_val);
					break;
				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		case 7:
#ifdef	DEBUG3
			printf("\n(DEST) @X(Rn) Index deferred mode\n");
#endif

			switch(dest_reg)
			{
				case 0:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R0;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 1:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R1;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 2:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R2;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 3:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R3;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 4:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R4;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 5:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R5;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 6:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R6_SP;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				case 7:
					temp_x = get_mem(PC_val);
					increment_PC_val(2);
					temp_addr = Reg_R7_PC;
					eff_addr = get_eff_addr(temp_addr, temp_x);
					temp_addr_of_addr = get_mem(eff_addr);
					set_pdp_memory(temp_addr_of_addr, src_val);
					break;

				default:
#ifdef	DEBUG3
					printf(" DEST reg %d doesn't exist\n",dest_reg);	
#endif
					break;


			}	
			break;

		default:
#ifdef	DEBUG3
			printf("Addressing mode %d doesn't exist\n",dest_mod);	
#endif
			break;


	}




#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;

}



int set_PSW_N()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_N = 1;

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int set_PSW_Z()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_Z = 1;


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int set_PSW_V()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_V = 1;

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int set_PSW_C()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_C = 1;

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int clear_PSW_N()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_N = 0;


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int clear_PSW_Z()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_Z = 0;


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int clear_PSW_V()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_V = 0;


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}




int clear_PSW_C()
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PSW_C = 0;


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}


int get_eff_addr(int rn, int x)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif
	int eff_num = 0;
	//int two; 

#ifdef	DEBUG3
	printf("rn = %d (%o) \n",rn, rn);
	printf("x = %d (%o) \n",x, x);
#endif


	eff_num = ((rn + x) & 0xFFFF);

	/*
	   two = (~x) & 0xFFFF;	//One's compliment for 16 bits 
	   two = two + 1;	//Two's compliment  

	   eff_num = rn - two;

#ifdef	DEBUG3
printf("eff_num = %d (%o) \n",eff_num);
printf("two = %d (%o) \n",two);
#endif
	 */

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return eff_num; 

}


int write_to_trace(int opera, int address) 
{

	fprintf(trace, "%o\t%o\n", opera, address);

	return 0;

}


int write_to_br_trace(int PC_br_val, int opcode, int address, int decision)
{
	switch ((opcode >> 12)& 017) 
	{
		case 000:
			switch ((opcode >> 6) & 077)
			{
				case 001:
					if (decision == 1)
					{   
						fprintf(br_trace, "%o\t\t\tJMP\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tJMP\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 002:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tRTS\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tRTS\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 004: case 005: case 006: case 007:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBR\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBR\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 010: case 011: case 012: case 013:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBNE\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBNE\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 014: case 015: case 016: case 017:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBEQ\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBEQ\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 020: case 021: case 022: case 023:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBGE\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBGE\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 024: case 025: case 026: case 027:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBLT\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBLT\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 030: case 031: case 032: case 033:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBGT\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBGT\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 034: case 035: case 036: case 037:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBLE\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBLE\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 040: case 041: case 042: case 043: case 44: case 45: case 46: case 47:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tJSR\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tJSR\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;

			}
		case 001:
			switch ((opcode >> 6) & 077)
			{
				case 007:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tSOB\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tSOB\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
			}
		case 010:
			switch ((opcode >> 6) & 077)
			{

				case 001: case 002: case 003: case 000:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBPL\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBPL\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 004: case 005: case 006: case 007:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBMI\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBMI\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 010: case 011: case 012: case 013:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBHI\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBHI\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 014: case 015: case 016: case 017:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBLOS\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBLOS\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 020: case 021: case 022: case 023:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBVC\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBVC\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 024: case 025: case 026: case 027:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBVS\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBVS\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 030: case 031: case 032: case 033:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBCC/BHIS\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBCC/BHIS\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
				case 034: case 035: case 036: case 037:
					if (decision == 1)
					{
						fprintf(br_trace, "%o\t\t\tBCS/BLO\t\t\t%o\t\tTAKEN\n", PC_br_val, address);
					}
					else if(decision == 0)
					{
						fprintf(br_trace, "%o\t\t\tBCS/BLO\t\t%o\t\tNOT TAKEN\n", PC_br_val, address);
					}
					break;
			}
			break;
	}
	return 0;
}

int JMP_PC(int x)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PC_val = (x);
	Reg_R7_PC = PC_val;	

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}


int BRANCH_forw(int x)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PC_val = (PC_val + (((x) + (x)) & 0377)) & 0177777;
	Reg_R7_PC = PC_val;	

#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}


int BRANCH_back(int x)
{
#ifdef	DEBUG3
	printf("\nEntering function %s\n",__func__);
#endif

	PC_val = (PC_val + (((x) + (x)) | 0177400)) & 0177777;
	Reg_R7_PC = PC_val;	


#ifdef	DEBUG3
	printf("\nExiting function %s\n",__func__);
#endif
	return 0;
}

int decrement_Reg_val(int count, int reg)
{
	switch(reg)
	{
		case 0:
			Reg_R0 = Reg_R0 - 2;
			break;

		case 1:
			Reg_R1 = Reg_R1 - 2;
			break;

		case 2:
			Reg_R2 = Reg_R2 - 2;
			break;

		case 3:
			Reg_R3 = Reg_R3 - 2;
			break;

		case 4:
			Reg_R4 = Reg_R4 - 2;
			break;

		case 5:
			Reg_R5 = Reg_R5 - 2;
			break;

		case 6:
			Reg_R6_SP = Reg_R6_SP - 2;
			break;

		case 7:
			Reg_R7_PC = Reg_R7_PC - 2;
			break;

	}


	return 0;
}

int increment_Reg_val(int count, int reg)
{
	switch(reg)
	{
		case 0:
			Reg_R0 = Reg_R0 + 2;
			break;

		case 1:
			Reg_R1 = Reg_R1 + 2;
			break;

		case 2:
			Reg_R2 = Reg_R2 + 2;
			break;

		case 3:
			Reg_R3 = Reg_R3 + 2;
			break;

		case 4:
			Reg_R4 = Reg_R4 + 2;
			break;

		case 5:
			Reg_R5 = Reg_R5 + 2;
			break;

		case 6:
			Reg_R6_SP = Reg_R6_SP + 2;
			break;

		case 7:
			Reg_R7_PC = Reg_R7_PC + 2;
			break;

	}


	return 0;
}


int avoid_repeat(int mode, int reg)
{
	if((mode == 06) | (mode == 07))
	{
		decrement_PC_val(2);
	}

	if((mode == 02) | (mode == 03))
	{
		decrement_Reg_val(2, reg);
	}

	if((mode == 04) | (mode == 05))
	{
		increment_Reg_val(2, reg);
	}


	return 0;

}


