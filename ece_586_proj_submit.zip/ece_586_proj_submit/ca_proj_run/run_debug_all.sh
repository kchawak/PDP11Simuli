#!/bin/bash


timestamp=$(date +%m-%d-%Y-%T)


echo "									"
echo "   ##################################################################"
echo "   #                                                                #"
echo "   #               ECE-586 Computer Architecture                    #"
echo "   #            Final project : PDP-11 ISA simulation               #"
echo "   #                       $timestamp                      #"
echo "   #                                                                #"
echo "   # Team members                                                   #"
echo "   # - Amit Solapurkar                                              #"
echo "   # - Kalyani Chawak                                               #"
echo "   # - Kushal Shah                                                  #"
echo "   # - Yuvanesh Madras Somasundaram                                 #"
echo "   #                                                                #"
echo "   #                                                                #"
echo "   ##################################################################"
echo "									"


make clean


echo "									"

make SFLAGS=-DSTEP DFLAGS=-DDEBUG DALLFLAGS=-DDEBUG3

echo "									"

echo "Enter the starting PC value if '*' is not present in ascii file"

./pdp_build $1 



echo "									"


