/////////////////////////////////////////////////////////////

#ifndef __OPCODE_H__
#define __OPCODE_H__



/******************************************************************************/
/*
Double operand start (4 MSB bits)
 */
/******************************************************************************/

#define MASK_2OP	0xFF0000

#define OPCODE_MOV	1
#define OPCODE_MOVB	11

#define OPCODE_CMP	2
#define OPCODE_CMPB	12

#define OPCODE_BIT	3
#define OPCODE_BITB	13

#define OPCODE_BIC	4
#define OPCODE_BICB	14

#define OPCODE_BIS	5
#define OPCODE_BISB	15

#define OPCODE_ADD	6

#define OPCODE_SUB	16


/******************************************************************************/
/*
Double operand end (4 MSB bits)
 */
/******************************************************************************/


/******************************************************************************/
/*
Single operand start
 */
/******************************************************************************/

#define OPCODE_CLR	50
#define OPCODE_CLRB	1050

#define OPCODE_COM	51
#define OPCODE_COMB	1051

#define OPCODE_INC	52
#define OPCODE_INCB	1052

#define OPCODE_DEC	53
#define OPCODE_DECB	1053

#define OPCODE_NEG	54
#define OPCODE_NEGB	1054

#define OPCODE_ADC	55
#define OPCODE_ADCB	1055

#define OPCODE_SBC	56
#define OPCODE_SBCB	1056

#define OPCODE_TST	57
#define OPCODE_TSTB	1057

#define OPCODE_ROR	60
#define OPCODE_RORB	1060

#define OPCODE_ROL	61
#define OPCODE_ROLB	1061

#define OPCODE_ASR	62
#define OPCODE_ASRB	1062

#define OPCODE_ASL	63
#define OPCODE_ASLB	1063

#define OPCODE_JMP	1

#define OPCODE_SWAB	3

/******************************************************************************/
/*
Single operand end
 */
/******************************************************************************/






/******************************************************************************/
/*
Conditional branches start (8 MSB bits)
 */
/******************************************************************************/

#define OPCODE_BR	4

#define OPCODE_BNE	10

#define OPCODE_BEQ	14

#define OPCODE_BGE	20

#define OPCODE_BLT	24

#define OPCODE_BGT	30

#define OPCODE_BLE	34

#define OPCODE_BPL	1000

#define OPCODE_BMI	1004

#define OPCODE_BHI	1010

#define OPCODE_BLOS	1014

#define OPCODE_BVC	1020

#define OPCODE_BVS	1024

#define OPCODE_BCC	1030   //or BHIS

#define OPCODE_BCS	1034   // or BLO

/******************************************************************************/
/*
Conditional branches end (8 MSB bits)
 */
/******************************************************************************/




/******************************************************************************/
/*
Subroutine call(7 MSB bits) / return(13 MSB bits) start
 */
/******************************************************************************/

#define OPCODE_JSR	4

#define OPCODE_RTS	20

/******************************************************************************/
/*
Subroutine call(7 MSB bits) / return(13 MSB bits) end
 */
/******************************************************************************/



/******************************************************************************/
/*
No operand instruction / condition code modification start
 */
/******************************************************************************/

#define OPCODE_HALT	0

#define OPCODE_CLC	241

#define OPCODE_CLV	242

#define OPCODE_CLZ	244

#define OPCODE_CLN	250

#define OPCODE_CCC	257

#define OPCODE_SEC	261

#define OPCODE_SEV	262

#define OPCODE_SEZ	264

#define OPCODE_SEN	270

#define OPCODE_SCC	277

/******************************************************************************/
/*
No operand instruction / condition code modification end
 */
/******************************************************************************/



#endif     //// __OPCODE_H__
