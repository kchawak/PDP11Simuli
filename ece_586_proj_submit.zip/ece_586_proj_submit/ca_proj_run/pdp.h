/////////////////////////////////////////////////////////////

#ifndef __PDP_H__
#define __PDP_H__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "opcode.h"



/******************************************************************************/
/*
Global variables section start
 */
/******************************************************************************/


int pdp_memory[64*1024*2];

int Reg_R0 = 0;
int Reg_R1 = 0;
int Reg_R2 = 0;
int Reg_R3 = 0;
int Reg_R4 = 0;
int Reg_R5 = 0;
int Reg_R6_SP = 0;
int Reg_R7_PC = 0;

int PC_val = 0;
int PC_val_given = 0;
int load_ptr = 0;

int number_of_instr = 0;

int halt = 0;

int PSW_N = 0;
int PSW_Z = 0;
int PSW_V = 0;
int PSW_C = 0;


/******************************************************************************/
/*
Global variables section end
 */
/******************************************************************************/


#define GET_SIGN_W(v)   (((v) >> 15) & 1)
#define GET_SIGN_B(v)   (((v) >> 7) & 1)
#define GET_PSW_Z(v)        ((v) == 0)



/******************************************************************************/
/*
Function declaration section start
 */
/******************************************************************************/


int load_memory(FILE *fp);
int init_pdp_memory();
int extract_val(char *test_input_ascii);
int store_pdp_memory(int temp_load_ptr, int temp_data);
int set_pdp_memory(int temp_load_ptr, int temp_data);
int get_pdp_memory(int temp_load_ptr);
int increment_load_ptr(int count);
int increment_PC_val(int count);
int update_load_ptr(int temp_load_ptr);
int print_memory();
int print_registers();
int print_status_flags();

int instr_fetch();
int instr_decode(int temp_instr);
int instr_decode_2opera(int temp_instr);
int instr_decode_0opera(int temp_instr);
int instr_decode_1opera(int temp_instr);
int instr_decode_branch(int temp_instr);
int opcode_mov(int temp_instr);
int opcode_add(int temp_instr);
int get_src_val(int src_mod, int src_reg);
int get_dest_val(int dest_mod, int dest_reg);
int write_dest_val(int dest_mod, int dest_reg, int src_val);
int oct_to_deci(int octal);
int write_to_trace(int opera, int address); 

int set_PSW_N();
int set_PSW_Z();
int set_PSW_V();
int set_PSW_C();

int clear_PSW_N();
int clear_PSW_Z();
int clear_PSW_V();
int clear_PSW_C();

int JMP_PC(int x);
int BRANCH_forw(int x);
int BRANCH_back(int x);
int get_eff_addr(int rn, int x);
int avoid_repeat(int mode, int reg);
int print_memory_addr(int addr);
int print_memory_range(int addr, int space);
int deci_to_oct(int deci);
int write_to_br_trace(int PC_br_val, int opcode, int address, int decision);
int get_dest_addr(int dest_mod, int dest_reg);
/******************************************************************************/
/*
Function declaration section end
 */
/******************************************************************************/


#endif     //// __PDP_H__
